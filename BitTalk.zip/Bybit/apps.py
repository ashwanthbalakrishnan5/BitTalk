from django.apps import AppConfig


class BybitConfig(AppConfig):
    name = 'Bybit'
