from django.apps import AppConfig


class BinanceConfig(AppConfig):
    name = 'Binance'
